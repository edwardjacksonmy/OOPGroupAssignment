SELECT count(1)
FROM useraccount
WHERE username = 'admin' && password = '1234';