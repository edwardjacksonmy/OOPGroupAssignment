INSERT INTO `java2`.`useraccount` (username, password)
VALUES ('admin','1234');


